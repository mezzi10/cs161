<?php require_once'connect_database.php'; ?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="templates.css">
    </head>
    <body>
        <!--This is the main banner 
        Last Altered 28 Feb. 2018-->
        <div class="header">
            <div class="title">Skill Scanner</div>
            <a class="btn btn-primary" href="destroy_session.php">
                <button onclick="document.getElementById('login').style.display = 'block'" style="width:auto;" class="loginbtn">Log Out</button></a>

        </div>


        <!--This is the Login Form 
        Last Altered 28 Feb. 2018-->
        <div id="login" class="modal">

            <form class="modal-content animate" action="login.php">
                <div class="closecontainer">
                    <span onclick="document.getElementById('login').style.display = 'none'" class="close" title="Close Login">&times;</span>
                </div>

                <div style="width:450px;margin-left: 35%;text-align: center;background-color: chartreuse" class="welcome">
                    <p style="color: red;"><b><?php
                   
                            if (isset($_SESSION["set"])) {                                
                                echo 'Please select a file!';
                            } else
                                echo "Welcome Back " . strtoupper($_SESSION["username"]) . "!";
                            ?></b></p>
                </div>


            </form>  
        </div>
        <!--This is the Registration form
        Last Altered 28 Feb. 2018-->


        <!--This is the main content area. As of 8 March it is being updated to include
        the forms we will allow users to access
        Last Altered 14 March 2018-->

        <div class="mainContent">
            <div id="selector" class = "container">

            </div>
            <style>                
                #data{
                   border:1px solid green; 
                }
            </style>
            <div style="float: right;border: 1px dotted activecaption;width: 150px">
                <table>
                    <th>Your Companies:</th>
<?php
$rowRes = $conn->query("SELECT DiSTINCT company FROM skills WHERE  uname = '$username'  ");
                
                    $count = $rowRes->num_rows;
                if ($count > 0) {
                        $i = 1;
                        while ($row = $rowRes->fetch_assoc()) {
                            echo '<tr>';
                             echo '<td id="data">';
                            echo strtoupper($row['company']);
                             echo '</td>';
                             echo '</tr>';
                             
                            $i++;
                        }
                }

?>
                </table>
           
        </div>

            <form id = "forRecruiters"  action="recruiterParser.php" method="post" enctype="multipart/form-data">

                <label for="company"><b>Company Name</b></label>
                <select name="company">
                    <option value="intel">Intel</option>
                    <option value="facebook">Facebook</option>
                    <option value="HewlettPackard">Hewlett-Packard</option>
                    <option value="ibm">IBM</option>
                    <option value="google">Google</option>
                    <option value="apple">Apple</option>
                    <option value="microsoft">Microsoft</option>
                    <option value="Ciscosystems">Cisco Systems</option>
                    <option value="amazon">Amazon</option>
                    <option value="tesla">Tesla</option>
                    <option value="adobe">Adobe</option>
                    <option value="cyber">Cyber</option>
                    <option value="chegg">Chegg</option>
                    <option value="udime">Udime</option>
                </select><br>
                <label for="posTitle"><b>Position Title</b></label>
                <select name="posTitle">
                    <option value="Software Engineer">Software Engineer</option>
                    <option value="Front-end Engineer">Front-end Engineer</option>
                    <option value="Project Manager">Project Manager</option>
                    <option value="Project Developer">Project Developer</option>
                    <option value="UX Engineer">UX Engineer</option>
                    <option value="Security Engineer">Security Engineer</option>
                    <option value="Data Analysist">Data Analysist</option>
                    <option value="Mechanical Engineer">Mechanical Engineer</option>
                    <option value="Technical Solution Manager">Technical Solution Manager</option>
                    <option value="System Administrator">System Administrator</option>
                    <option value="Application Developer">Application Developer</option>
                    <option value="System Administrator">System Administrator</option>
                    <option value="Cloud Architect">Cloud Architect</option>
                    <option value="Computer Network Architect">Computer Network Architect</option>
                    <option value="Computer Programmer">Computer Programmer</option>
                    <option value="Data Quality Manager">Data Quality Manager</option>
                    <option value="IT Analyst">IT Analyst</option>
                    <option value="IT Director">IT Director</option>
                    <option value="IT Manager">IT Manager</option>

                </select><br>



                <label for="recEXP"><b>Work Experience(Years)</b></label><br>
                <select name="recEXP">
                    <option value="noxp">0-1</option>
                    <option value="lowxp">2</option>
                    <option value="medxp">3</option>
                    <option value="highxp">4</option>
                    <option value="highxp">5</option>
                    <option value="highxp">+5</option>
                </select><br>

                <div class="line"></div><br>
                <div class="skill">

                    <div class="software_skills">   
                        <label for="skillSetR"><b>Software</b></label><br><br>
                        selenium<input type="checkbox" value="selenium" name="check[]" class="skills"><br> 
                        webipi<input type="checkbox" name="check[]" value="webipi " class="skills"><br> 
                        asp.net<input type="checkbox" name="check[]" value="asp.net" class="skills"><br> 
                        mvc<input type="checkbox" name="check[]" value="mvc" class="skills"><br> 
                        ftp<input type="checkbox" name="check[]" value="ftp" class="skills"><br> 
                        angularJS<input type="checkbox" name="check[]"  value="angularJS" class="skills"><br>
                        javascript<input type="checkbox" value="MongoDB" name="check[]" class="skills"><br> 
                        express.js<input type="checkbox" name="check[]" value="express.js" class="skills"><br>  
                        docker<input type="checkbox" name="check[]" value="docker" class="skills"><br> 
                        automation<input type="checkbox" name="check[]" value="automation" class="skills"><br> 
                        agile<input type="checkbox" name="check[]" value="agile" class="skills"><br>
                        jquery<input type="checkbox" name="check[]" value="devops" class="skills"><br>
                        photoshop<input type="checkbox" name="check[]" value="photoshop" class="skills"><br>
                        jflap<input type="checkbox" name="check[]" value="jflap" class="skills"><br>
                        html5<input type="checkbox" name="check[]" value="html5" class="skills"><br>
                        nodejs<input type="checkbox" name="check[]" value="nodejs" class="skills"><br>
                        bitbucket<input type="checkbox" name="check[]" value="bitbucket" class="skills"><br>
                        basic<input type="checkbox" name="check[]" value="basic" class="skills"><br>
                        github<input type="checkbox" name="check[]" value="github" class="skills"><br>
                        photoscape<input type="checkbox" name="check[]" value="photoscape" class="skills"><br>
                        sqlite<input type="checkbox" name="check[]" value="sqlite" class="skills"><br>
                        aws<input type="checkbox" name="check[]" value="aws" class="skills"><br>
                    </div> 

                    <div class="frontend_skills">  
                        <label for="skillSetR"><b>Front-End</b></label><br><br>
                        html5<input type="checkbox" value="html5" name="check[]" class="skills"><br> 
                        css3<input type="checkbox" name="check[]" value="css3" class="skills"><br> 
                        javascript<input type="checkbox" name="check[]" value="javascript" class="skills"><br> 
                        react<input type="checkbox" name="check[]" value="react" class="skills"><br> 
                        django<input type="checkbox" name="check[]" value="django" class="skills"><br> 
                        frameworks<input type="checkbox" name="check[]"  value="frameworks" class="skills"><br>
                        json<input type="checkbox" value="json" name="check[]" class="skills"><br> 
                        scheme<input type="checkbox" name="check[]" value="scheme" class="skills"><br>  
                        perl<input type="checkbox" name="check[]" value="perl" class="skills"><br> 
                        mysql<input type="checkbox" name="check[]" value="mysql" class="skills"><br> 
                        lisp<input type="checkbox" name="check[]" value="lisp" class="skills"><br>
                        jquery<input type="checkbox" name="check[]" value="jquery" class="skills"><br>
                        photoshop<input type="checkbox" name="check[]" value="photoshop" class="skills"><br>
                        jflap<input type="checkbox" name="check[]" value="jflap" class="skills"><br>
                        html5<input type="checkbox" name="check[]" value="html5" class="skills"><br>
                        nodejs<input type="checkbox" name="check[]" value="nodejs" class="skills"><br>
                        bitbucket<input type="checkbox" name="check[]" value="bitbucket" class="skills"><br>
                        basic<input type="checkbox" name="check[]" value="basic" class="skills"><br>
                        github<input type="checkbox" name="check[]" value="github" class="skills"><br>
                        photoscape<input type="checkbox" name="check[]" value="photoscape" class="skills"><br>
                        python<input type="checkbox" name="check[]" value="python" class="skills"><br>
                        css<input type="checkbox" name="check[]" value="css" class="skills"><br>

                    </div>
                    <div class="split"></div>

                    <div class="backend_skills">                      
                        <label for="skillSetR"><b>Back-End</b></label><br><br>
                        java<input type="checkbox" value="java" name="check[]" class="skills"><br> 
                        c++<input type="checkbox" name="check[]" value="c++" class="skills"><br> 
                        c<input type="checkbox" name="check[]" value="c" class="skills"><br> 
                        python<input type="checkbox" name="check[]" value="python" class="skills"><br> 
                        nosql<input type="checkbox" name="check[]" value="nosql" class="skills"><br> 
                        php<input type="checkbox" name="check[]"  value="php" class="skills"><br>
                        javascript<input type="checkbox" value="javascripts" name="check[]" class="skills"><br> 
                        scheme<input type="checkbox" name="check[]" value="scheme" class="skills"><br>  
                        perl<input type="checkbox" name="check[]" value="perl" class="skills"><br> 
                        mysql<input type="checkbox" name="check[]" value="mysql" class="skills"><br> 
                        lisp<input type="checkbox" name="check[]" value="lisp" class="skills"><br>
                        jquery<input type="checkbox" name="check[]" value="jquery" class="skills"><br>
                        photoshop<input type="checkbox" name="check[]" value="photoshop" class="skills"><br>
                        jflap<input type="checkbox" name="check[]" value="jflap" class="skills"><br>
                        html5<input type="checkbox" name="check[]" value="html5" class="skills"><br>
                        nodejs<input type="checkbox" name="check[]" value="nodejs" class="skills"><br>
                        bitbucket<input type="checkbox" name="check[]" value="bitbucket" class="skills"><br>
                        basic<input type="checkbox" name="check[]" value="basic" class="skills"><br>
                        uml<input type="checkbox" name="check[]" value="uml" class="skills"><br>
                        debuging<input type="checkbox" name="check[]" value="debuging" class="skills"><br>
                        android<input type="checkbox" name="check[]" value="android" class="skills"><br>
                        javaSwing<input type="checkbox" name="check[]" value="javaSwing" class="skills"><br>       
                    </div>

                    <br><br><br>



                </div>
                <input name="file2" style="display: none"/>  
                <input name="file" type="file"/> 
                <button type="submit" name="submit">submit</button>        


            </form>
            <div class="line"></div><br>





        </div>
        
        <!--This is the javascript section
        UPDATE: Added functionality to switch between forms via radio button
        Last Altered 8 March 2018-->
        <script>
            // Get the modal
            var modal = document.getElementById('login');

            // Get the modal
            var modal2 = document.getElementById('register');


            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function (event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
                if (event.target == modal2) {
                    modal2.style.display = "none";
                }
            }


            //Added 8 March 2018
            function switchView() {
                var seek = document.getElementById('seekCheck');
                var rec = document.getElementById('recCheck');
                if (seek.checked == true) {
                    document.getElementById('forSeekers').style.display = "block";
                    document.getElementById('forRecruiters').style.display = "none";
                }
                if (rec.checked == true) {
                    document.getElementById('forSeekers').style.display = "none";
                    document.getElementById('forRecruiters').style.display = "block";
                }

            }



        </script>

    </body>
</html>