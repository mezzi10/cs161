<?php

//connect to database
require_once 'connect_database.php';

//destroy session after user logs out
session_destroy();
//set username to empty string
$_SESSION["username"] == "";
//forward user to log in page
header("location: index.php");
?>