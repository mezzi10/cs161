<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
        <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.11.4/themes/ui-lightness/jquery-ui.css">
        <title></title>
    </head>
    <body>

        <?php
        $name1 = $name2 = $name3 = $name4 = $name5 = $name6 = $name7 = $name8 = $name9 = $name10 = "";
        $comp1 = $comp2 = $comp3 = $comp4 = $comp5 = $comp6 = $comp7 = $comp8 = $comp9 = $comp10 = "";
        $var1 = $var2 = $var3 = $var4 = $var5 = $var6 = $var7 = $var8 = $var9 = $var10 = 0;
        $conName = "ALL";
        $count = 0;
        ?>
        <?php
        require_once'connect_database.php';
        // if(!isset($_SESSION["username"])){
        //  header("location:register.html");
        $have_skill = array();
        $dontHave_skill = array();
        //}
        $username = $_SESSION["username"];
        $var1 = $var2 = $var2 = $var3 = $var4 = $var5 = $var6 = $var7 = 0;



        $percentage = 0;
        //&& $_SERVER['PHP_SELF'] != "/cs161b/recruiterParser.php"
        if (isset($_FILES['file']) && !empty($_POST['file'])) {

            switch ($_FILES['file']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    //$_SESSION["set"] = true;
                    header("location:" . $_SERVER['HTTP_REFERER']);
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                default:
                    throw new RuntimeException('Unknown errors.');
            }
            $target_file = basename($_FILES["file"]["name"]);
            // SplFileObject::next(void);
            $extension = pathinfo($target_file, PATHINFO_EXTENSION);
            $length = strlen($extension);
            $conName = substr($target_file, 0, strlen($target_file) - ($length + 1));

            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {


                $myfile = fopen($target_file, "r");
                $file = new SplFileObject($target_file);

//                $have_skill = array();
//                $dontHave_skill = array();
                //if username field is empty...print error 'required'
                if (empty($_POST['check[]']) && empty($_POST['posTitle'])) {
                    $skillRequired = "Required*";

                    //if username field is not empty...get the submitted value
                }
                //if username field is empty...print error 'required'
                if (empty($_POST['company'])) {
                    $cmpRequired = "Required*";

                    //if username field is not empty...get the submitted value
                } else {
                    $company = mysql_fix_string($conn, $_POST['company']);
                }
                $rowcount = "";
                $posTitle = $_POST['posTitle'];

                function read_docx($filename) {

                    $striped_content = '';
                    $content = '';

                    if (!$filename || !file_exists($filename))
                        return false;

                    $zip = zip_open($filename);
                    if (!$zip || is_numeric($zip))
                        return false;

                    while ($zip_entry = zip_read($zip)) {

                        if (zip_entry_open($zip, $zip_entry) == FALSE)
                            continue;

                        if (zip_entry_name($zip_entry) != "word/document.xml")
                            continue;

                        $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

                        zip_entry_close($zip_entry);
                    }
                    zip_close($zip);
                    $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
                    $content = str_replace('</w:r></w:p>', "\r\n", $content);
                    $striped_content = strip_tags($content);

                    return $striped_content;
                }

                function match($content) {
                    global $target_file, $percentage, $have_skill, $extension, $dontHave_skill, $company, $conn, $rowcount, $username, $posTitle;
                    // if(isset($_POST['posTitle'])){
                    // $posTitle = $_POST['posTitle'];
                    //}
                    $rowRes = $conn->query("SELECT skills FROM skills WHERE company = '$company' AND uname = '$username' AND posTitle = '$posTitle'");
                    //go through the result set and see if it matches the password for that username

                    if ($rowRes->num_rows > 0) {
                        while ($row = $rowRes->fetch_assoc()) {

                            $skill = $row["skills"];

                            if ($skill == "c++") {
                                $pattern = "/$skill\+\+/i";
                            } else {

                                $pattern = "/$skill/i";
                            }

                            if (preg_match($pattern, $content, $matches)) {

                                //if(in_array($skill, $matches)){
                                if (!in_array($skill, $have_skill)) {

                                    array_push($have_skill, $skill);
                                }
                                //}
                            } else {

                                //if (!in_array($skill, $matches)) {
                                if (!in_array($skill, $dontHave_skill) && !in_array($skill, $have_skill)) {
                                    array_push($dontHave_skill, $skill);
                                }
                                //}
                            }
                        }
                        $rowcount = mysqli_num_rows($rowRes);
                    } else {
                        $percentage = 0;
                        //header("location:recruiter.php");
                    }


                    return false;
                }

                if ($extension == "docx") {
                    $content = read_docx($target_file);
                    $separator = "\r\n";
                    $line = strtok($content, $separator);

                    while ($line !== false) {

                        match($line);

                        $line = strtok($separator);
                    }
                    //$content = fgets($content);
                } else {
                    while (!$file->eof()) {
                        $content = fgets($myfile);

                        $content = trim($file->current());
                        match($content);

                        $file->next();
                    }
                }
                $percentage = sizeof($have_skill) * 100 / $rowcount;


                $stm1 = ("SELECT * FROM scan_result WHERE company='$company' AND uname = '$username' AND name = '$conName'");
                $rowRes = $conn->query($stm1);
                $count = $rowRes->num_rows;
                if ($count > 0) {

                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("UPDATE scan_result SET percentage='$percentage' WHERE company = '$company' AND uname= '$username' AND name = '$conName'");
                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "up";
                    }
                } else {

                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("INSERT INTO scan_result(uname,company,name,percentage,position) VALUES('$username','$company','$conName','$percentage','$posTitle')");

                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "pp";
                    }
                }


                $rowRes = $conn->query("SELECT * FROM scan_result order by percentage desc");


                $count = $rowRes->num_rows;
                if ($count > 0) {

                    $i = 1;

                    while ($row = $rowRes->fetch_assoc()) {
                        //${"var" . $i} = $row['percentage'];


                        ${"var" . $i} = $row["percentage"];

                        ${"name" . $i} = $row['name'];
                        ${"comp" . $i} = $row['company'];
                        $i++;
                    }
                }
            } else {


                $rowRes = $conn->query("SELECT * FROM scan_result LIMIT 10");

                $count = $rowRes->num_rows;
                if ($count > 0) {
                    $i = 1;
                    while ($row = $rowRes->fetch_assoc()) {
                        ${"var" . $i} = $row['percentage'];
                        ${"name" . $i} = $row['name'];
                        ${"comp" . $i} = $row['company'];

                        $i++;
                    }
                }
            }
        } else if (isset($_POST['posTitle']) && !isset($_POST['check'])) {

            $company = $_POST['company'];
            $posTitle = $_POST['posTitle'];

            // SplFileObject::next(void);

            $target_file = basename($_FILES["file"]["name"]);
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
                $file = new SplFileObject($target_file);

                $myfile = fopen($target_file, "r");
                $length = strlen(pathinfo($target_file, PATHINFO_EXTENSION));
                $conName = substr($target_file, 0, strlen($target_file) - ($length + 1));
                $rowRes = $conn->query("SELECT skills FROM skills WHERE company = '$company' AND uname = '$username' AND posTitle = '$posTitle'");
                $rowResArray = array();
                $have_skill = array();
                $i = 0;
                while ($row = $rowRes->fetch_assoc()) {
                    $rowResArray[$i] = $row['skills'];
                    $i++;
                }

                //********************
//                    $have_skill = array();
//                    $dontHave_skill = array();

                function match($content) {
                    global $percentage, $company, $conn, $rowcount, $username, $posTitle,
                    $have_skill, $dontHave_skill;
                    // if(isset($_POST['posTitle'])){
                    // $posTitle = $_POST['posTitle'];
                    //}

                    $rowRes = $conn->query("SELECT skills FROM skills WHERE company = '$company' AND uname = '$username' AND posTitle = '$posTitle'");
                    //go through the result set and see if it matches the password for that username

                    if ($rowRes->num_rows > 0) {

                        while ($row = $rowRes->fetch_assoc()) {

                            $skill = $row["skills"];

                            if ($skill == "c++") {
                                $pattern = "/$skill\+\+/i";
                            } else {

                                $pattern = "/$skill/i";
                            }

                            if (preg_match($pattern, $content, $matches)) {

                                //if(in_array($skill, $matches)){
                                if (!in_array($skill, $have_skill)) {

                                    array_push($have_skill, $skill);
                                } else {
                                    break;
                                }

                                //}
                            } else {

                                //if (!in_array($skill, $matches)) {

                                if (!in_array($skill, $dontHave_skill)) {

                                    array_push($dontHave_skill, $skill);
                                }
                            }
                            //}
                        }
                        $rowcount = mysqli_num_rows($rowRes);
                    } else {
                        $error = "messi";
                        header("location:recruiter.php?" . $error);
                    }


                    return false;
                }

                while (!$file->eof()) {

                    $content = fgets($myfile);
                    $content = trim($file->current());
                    match($content);

                    $file->next();
                }
                $percentage = ceil(sizeof($have_skill) * 100 / $rowcount);

                $stm1 = ("SELECT * FROM scan_result WHERE uname = '$username' AND name = '$conName' AND position = '$posTitle'");
                $rowRes = $conn->query($stm1);
                $count = $rowRes->num_rows;
                if ($count > 0) {

                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("UPDATE scan_result SET percentage='$percentage' WHERE company = '$company' AND uname= '$username' AND name = '$conName'");
                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "up";
                    }
                } else {
                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("INSERT INTO scan_result(uname,company,name,percentage,position) VALUES('$username','$company','$conName','$percentage','$posTitle')");

                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "pp";
                    }
                }







                $rowRes = $conn->query("SELECT * FROM scan_result WHERE uname = '$username' ORDER BY percentage DESC LIMIT 10");

                $count = $rowRes->num_rows;
                if ($count > 0) {
                    $i = 1;
                    while ($row = $rowRes->fetch_assoc()) {
                        ${"var" . $i} = $row['percentage'];
                        ${"name" . $i} = $row['name'];
                        ${"comp" . $i} = $row['company'];

                        $i++;
                    }
                }
                $rowRes = $conn->query("SELECT * FROM user WHERE title = 'candidate' ");


                if ($rowRes->num_rows > 0) {
                    $i = 1;

                    while ($row = $rowRes->fetch_assoc()) {
                        ${"email" . $i} = $row['email'];
                        //$fname = $row['fName'];
                        //$lname = $row['lName'];
                        //$phone = $row['phone'];
                        $i++;
                    }
                }
            } else {
                $_SESSION["set"] = true;
                header("location:recruiter.php");
            }
        } else if (!isset($_POST['file']) && (!isset($_POST['check']))) {
            header("location:index.php");
        } else {

            $skills = $_POST['check'];
            $company = $_POST['company'];
            $posTitle = $_POST['posTitle'];

            $rowRes = $conn->query("SELECT * FROM skills WHERE uname = '$username' AND company = "
                    . "'$company' AND posTitle = '$posTitle'");
            $rowResArray = array();
            while ($res = $rowRes->fetch_assoc()) {
                array_push($rowResArray, $res['skills']);
            }
            foreach ($skills as $skill) {


                // $rowResArray = mysqli_fetch_array($rowRes);

                if ($skill == "") {
                    
                } else {

                    if ($rowResArray != "") {

                        if (in_array($skill, $rowResArray)) {
                            
                        } else {

                            $stm = ("INSERT INTO skills(id,company,uname,skills,posTitle) VALUES('','$company','$username','$skill','$posTitle')");

                            if ($conn->query($stm) === true) {
                                
                            } else {
                                echo mysqli_error($conn) . "0";
                            }
                        }
                    } else {
                        //} else {

                        $stm = ("INSERT INTO skills(uname,company,skills,posTitle) VALUES('$username','$company','$skill','$posTitle')");
                        //$conn->query($stm);
                        if ($conn->query($stm) === true) {
                            
                        } else {
                            echo mysqli_error($conn) . "1";
                        }
                    }
                }
            }


            $rowRes = $conn->query("SELECT * FROM scan_result WHERE uname = '$username' AND position = '$posTitle'  ORDER BY percentage DESC LIMIT 10");
            $count = $rowRes->num_rows;
            if ($count > 0) {
                $i = 1;

                while ($row = $rowRes->fetch_assoc()) {

                    ${"var" . $i} = $row['percentage'];
                    ${"name" . $i} = $row['name'];
                    ${"comp" . $i} = $row['company'];
                    $i++;
                }
            }
            $rowRes = $conn->query("SELECT * FROM user WHERE title = 'candidate' ");

            if ($rowRes->num_rows > 0) {
                $i = 1;

                while ($row = $rowRes->fetch_assoc()) {

                    ${"email" . $i} = $row['email'];

                    $i++;
                }
            }
        }

        // }
//sanitize user input
        function mysql_fix_string($conn, $string) {
            if (get_magic_quotes_gpc()) {
                $string = stripslashes($string);
                return $conn->real_escape_string($string);
            } else
                return $string;
        }
        ?>
        <p> <?php
        if ($percentage >= 85) {
            echo "<p style='color:white;background-color: green;text-align:center'>$percentage% Match=>GoodFit!";
        } else
        if ($percentage >= 70) {
            echo "=><p style='color:white;background-color: green;text-align:center'>$percentage% Match=><b>Could FIT!</b>";
        } else
        if ($percentage < 70) {
            echo "<p style='color:white;background-color: green;text-align:center'>$percentage% Match=> <b>No FIT!</b></p>";
        }
        ?></p>
        <div class="header">            
            <a class="btn btn-primary" href="destroy_session.php">
                <button onclick="document.getElementById('login').style.display = 'block'" style="width:auto;color: red" class="loginbtn">Log Out</button></a>

        </div>
        <br><p id="ping" style="display: none;color: green">Candidates Were Notified Successfully!</p>
        <div style="margin-left: 90%;margin-top: -2%;">            
            <a style="background-color: #EAFAF1" class="btn btn-primary" href="#"/>
            <button id= "share"conclick="document.getElementById('login').style.display = 'block'" style="width:auto;color: red" >Share</button></a>

    </div>



    <div name="dv" class="chartcontainer">
        <script type="text/javascript">

            window.onload = function () {
                CanvasJS.addColorSet("greenShades",
                        [//colorSet Array

                            "green",
                            "MediumSeaGreen",
                            "#90EE90",
                            "#abebc6",
                            "#90EE90",
                            "#eafaf1",
                            "#f1948a ",
                            "#ec7063 ",
                            "#cb4335",
                            " #e74c3c"
                        ]);

                var chart = new CanvasJS.Chart("chartContainer", {
                    colorSet: "greenShades",
                    title: {
                        text: "Scan Result"
                    },
                    data: [
                        {
                            // Change type to "doughnut", "line", "splineArea", etc.
                            name: "dd",
                            type: "column",

                            dataPoints: [

                                {label: '<?php echo $name1 . "[" . $comp1 . "]"; ?>', y: <?php echo $var1; ?>, click: onClick1},
                                {label: '<?php echo $name2 . "[" . $comp2 . "]"; ?>', y: <?php echo $var2; ?>, click: onClick2},
                                {label: '<?php echo $name3 . "[" . $comp3 . "]"; ?>', y: <?php echo $var3; ?>, click: onClick3},
                                {label: '<?php echo $name4 . "[" . $comp4 . "]"; ?>', y: <?php echo $var4; ?>, click: onClick4},
                                {label: '<?php echo $name5 . "[" . $comp5 . "]"; ?>', y: <?php echo $var5; ?>, click: onClick5},
                                {label: '<?php echo $name6 . "[" . $comp6 . "]"; ?>', y: <?php echo $var6; ?>, click: onClick6},
                                {label: '<?php echo $name7 . "[" . $comp7 . "]"; ?>', y: <?php echo $var7; ?>, click: onClick7},
                                {label: '<?php echo $name8 . "[" . $comp8 . "]"; ?>', y: <?php echo $var8; ?>, click: onClick8},
                                {label: '<?php echo $name9 . "[" . $comp9 . "]"; ?>', y: <?php echo $var9; ?>, click: onClick9},
                                {label: '<?php echo $name10 . "[" . $comp10 . "]"; ?>', y: <?php echo $var10; ?>, click: onClick10},
                            ]
                        }
                    ]
                });
                chart.render();
                function onClick1(e) {
                    location.href = "mailto:<?php
        echo $name1 . "@hotmail.com"
        ?>";
                }
                function onClick2(e) {
                    location.href = "mailto:<?php echo $name2 . "@gmail.com" ?>";
                }
                function onClick3(e) {
                    location.href = "mailto:<?php echo $name3 . "@sjsu.edu" ?>";
                }
                function onClick4(e) {
                    location.href = "mailto:<?php echo $name4 . "@yahoo.fr" ?>";
                }
                function onClick5(e) {
                    location.href = "mailto:<?php echo $name5 . "@gmail.com" ?>";
                }
                function onClick6(e) {
                    location.href = "mailto:<?php echo $name6 . "@hotmail.com" ?>";
                }
                function onClick7(e) {
                    location.href = "mailto:<?php echo $name7 . "@gmail.com" ?>";
                }
                function onClick8(e) {
                    location.href = "mailto:<?php echo $name8 . "@sjsu.edu" ?>";
                }
                function onClick9(e) {
                    location.href = "mailto:<?php echo $name9 . "@gmail.com" ?>";
                }
                function onClick10(e) {
                    location.href = "mailto:<?php echo $name10 . "@hotmail.com" ?>";
                }



            }





        </script>

    </div>
    <div id="chartContainer" style="height: 400px; width: 100%; "></div>
    <div  style="height: 2px; width: 100%;background-color: darkslategrey"></div><br>
    <div style="background-color: #CCCCCC;height: 50px;border: 1px dotted red;width:35% ">
        <p><b>Position:</b> <?php echo $posTitle; ?>,    <b>Company:</b> <?php echo $company; ?>,<br> <b>Candidate:</b> <?php echo $conName; ?></p>
    </div>
    <div  style="height: 2px; width: 100%;background-color: darkslategrey"></div>
    <div style="height: auto; width: 100%;float:right;background-color: #CCCCCC; ">

        <div id="call" style=" margin: auto;
             background-color: #f1f1f1;
             width: 30%;
             border: 1px solid green;
             padding: 10px;text-align: center;float: left;">
             <?php
             $name = strstr($conName, '_');
             $lname = substr($name, 1);
            
             $rowRes = $conn->query("SELECT * FROM user WHERE title = 'candidate' AND lName ='$lname'");

             if ($rowRes->num_rows > 0) {
                 $i = 1;

                 while ($row = $rowRes->fetch_assoc()) {
                     $email = $row['email'];
                     $fname = toUpper($row['fName']);
                     $lname = toUpper($row['lName']);
                     $phone = $row['phone'];
                     echo <<<EOL
                        
                        <a style='background-color:  #EAFAF1 ;
                        height:33px;
    color: black;
    padding: 14px 15px;
    border-style: groove;
    border: 1px dotted green;
    border-width: 1px;
    border-color: coral; 
    text-align: center;
    text-decoration: none;
    display: inline-block;' href="mailto:$email?body=''">$fname $lname | <u>Email</u> | $phone </a>
     <div  style="height: 2px; width: 100%;background-color: darkslategrey"></div>                           
EOL;

                     echo '<br>';
                 }
             } else {
                 $rowRes = $conn->query("SELECT DISTINCT name FROM scan_result WHERE uname = '$username' LIMIT 10");

                 if ($rowRes->num_rows > 0) {
                     $i = 1;
                     while ($row = $rowRes->fetch_assoc()) {
                         $name = strstr($row['name'], '_');
                         $lname = substr($name, 1);
                         $rowRes2 = $conn->query("SELECT * FROM user WHERE title = 'candidate' AND lName LIKE'%$lname'");
                         while ($row2 = $rowRes2->fetch_assoc()) {
                             $email = $row2['email'];
                             $fname = toUpper($row2['fName']);
                             $lname = toUpper($row2['lName']);
                             $phone = $row2['phone'];
                             echo <<<EOL
                        
                        <a style='background-color:  #EAFAF1 ;
                        height:33px;
    color: black;
    padding: 14px 15px;
    border-style: groove;    
    border-width: 1px;
    border-color: coral; 
    text-align: center;
    text-decoration: none;
    display: inline-block;' href="mailto:$email?body=''">$fname $lname | <u>Email</u> | $phone </a>
     <div  style="height: 2px; width: 100%;background-color: darkslategrey"></div>                           
EOL;

                             echo '<br>';
                             break;
                         }
                     }
                 }
             }

             function toUpper($value) {
                 return strtoupper($value);
             }
             ?>
        </div>
        <div style=" margin: auto;
             width: 30%;
             border: 1px dotted green;
             padding: 10px;text-align: center;float: right;">

            <p id ="skil" style=" margin: auto; text-align: center;
               width: 30%;
               border: 1px dotted green ;
               padding: 10px;"><b>Have Skills:</b></p>
               <?php
               foreach ($have_skill as $skill) {
                   if (in_array($dontHave_skill, $have_skill)) {
                       
                   } else {
                       echo '<p>';
                       echo $skill;
                       echo '</p>';
                   }
               }
               ?>
        </div>

        <div style=" margin: auto;
             width: 30%;
             border: 1px dotted red;
             padding: 10px;text-align: center;">
            <p style=" margin: auto; text-align: center;
               width: 50%;
               border: 1px dotted red ;
               padding: 10px;"><b>Missing Skills:</b></p>
            <?php
            foreach ($dontHave_skill as $skill) {
                if (in_array($skill, $have_skill)) {
                    
                } else {
                    echo '<p>';
                    echo $skill;
                    echo '</p>';
                }
            }
            ?>
        </div>
    </div>
    <script>
        $("#share").click(function () {
            $("#ping").toggle();

            $("#ping").fadeOut(1600);
        });
    </script>

</body>
</html>
