-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2018 at 08:44 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cs161`
--

-- --------------------------------------------------------

--
-- Table structure for table `canresult`
--

CREATE TABLE `canresult` (
  `name` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `percentage` int(150) NOT NULL,
  `id` int(150) NOT NULL,
  `position` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `canresult`
--

INSERT INTO `canresult` (`name`, `company`, `percentage`, `id`, `position`) VALUES
('Messi_Chaib', 'noPref', 100, 1, 'Software Engineer'),
('Messi_Chaib', 'apple', 60, 2, 'Software Engineer'),
('skills', 'noPref', 0, 3, 'Software Engineer'),
('skill', 'noPref', 34, 4, 'Software Engineer'),
('Jack_Daniel', 'facebook', 100, 5, 'Software Engineer'),
('James_Carry', 'facebook', 100, 6, 'Software Engineer'),
('Jack_Daniel', 'noPref', 100, 7, 'Software Engineer');

-- --------------------------------------------------------

--
-- Table structure for table `scan_result`
--

CREATE TABLE `scan_result` (
  `name` varchar(50) NOT NULL,
  `id` int(200) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `percentage` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scan_result`
--

INSERT INTO `scan_result` (`name`, `id`, `uname`, `company`, `percentage`) VALUES
('Amrane_Chaib', 58, 'messi', 'noPref', 34),
('Edi_Edison', 59, 'messi', 'noPref', 67),
('Fetima_Menadi', 60, 'messi', 'noPref', 34),
('Jack_Daniel', 61, 'messi', 'noPref', 100),
('James_Carry', 62, 'messi', 'noPref', 100),
('Jay_Jau', 63, 'messi', 'noPref', 100),
('Massi_Mason', 64, 'messi', 'noPref', 100);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(200) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `skills` varchar(50) NOT NULL,
  `posTitle` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `uname`, `company`, `skills`, `posTitle`) VALUES
(36, 'messi', 'apple', 'c', 'Software Engineer'),
(37, 'messi', 'apple', 'java', 'Software Engineer'),
(38, 'messi', 'apple', 'c++', 'Software Engineer'),
(39, 'messi', 'apple', 'c--', 'Software Engineer'),
(40, 'messi', 'apple', 'ruby', 'Software Engineer'),
(41, 'messi', 'noPref', 'java', 'Software Engineer'),
(42, 'messi', 'noPref', 'c', 'Software Engineer'),
(43, 'messi', 'facebook', 'java', 'Software Engineer'),
(44, 'messi', 'noPref', 'java', 'Front-end Engineer'),
(59, 'messi', 'noPref', 'c++', 'Software Engineer'),
(60, 'messi', 'noPref', 'basic', 'Software Engineer'),
(61, 'messi', 'noPref', 'php', 'Software Engineer');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `title` varchar(20) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passWord` varchar(50) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`title`, `userName`, `email`, `passWord`, `fName`, `lName`, `phone`) VALUES
('candidate', 'amrane', 'amrane.chaib@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'amrane', 'chaib', '510-456-8764'),
('candidate', 'edi', 'edi.edisson@yahoo.fr', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'edi', 'edisson', '617-987-5465'),
('candidate', 'fetima47', 'fetima47@yahoo.fr', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'fetima', 'menadi', '510-456-9876'),
('candidate', 'jack2', 'c.jack@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jack2', 'howard', '510-456-9876'),
('candidate', 'jack21', 'jack21@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jack', 'daniel', '415-876-5432'),
('recruiter', 'jackjay', 'jayjack@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jayjack', 'jim', '510-345-9876'),
('candidate', 'james', 'c.james@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'james', 'carry', '925-345-9876'),
('candidate', 'jameson', 'jameson12@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jameson', 'brad', '510-456-8765'),
('candidate', 'jason', 'c.jason@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jason', 'more', '510-467-8759'),
('candidate', 'jay', 'jay@sjsu.edu', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jay', 'jau', '510458-9876'),
('candidate', 'jay2', 'jay2@sjsu.edu', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jay', 'jau', '510458-9876'),
('candidate', 'jerry', 'jerry12@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jerry', 'jeffersson', '510-345-9876'),
('candidate', 'jim', 'c.mez@tex@sjsu.edu', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jim', 'brown', '510456-9875'),
('candidate', 'juba', 'juba.izem@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'juba', 'izem', '510-345-9854'),
('candidate', 'massi10', 'massi10@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'massi', 'mason', '510-654-9876'),
('recruiter', 'messi', 'c.mezzi55@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'messi', 'chaib', '5104578759'),
('candidate', 'mezzi', 'c.messi55@hotmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'mezzi', 'chaib', '5104568778');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `canresult`
--
ALTER TABLE `canresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scan_result`
--
ALTER TABLE `scan_result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `canresult`
--
ALTER TABLE `canresult`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `scan_result`
--
ALTER TABLE `scan_result`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
