<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
        <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.11.4/themes/ui-lightness/jquery-ui.css">
        <title></title>
    </head>
    <body>
        
        <?php
        $name1 = $name2 = $name3 = $name4 = $name5 = $name6 = $name7 = $name8 = $name9 = $name10 = "";
        $comp1 = $comp2 = $comp3 = $comp4 = $comp5 = $comp6 = $comp7 = $comp8 = $comp9 = $comp10 = "";
        $var1 = $var2 = $var3 = $var4 = $var5 = $var6 = $var7 = $var8 = $var9 = $var10 = 0;
        ?>
        <?php
        require_once'connect_database.php';
        // if(!isset($_SESSION["username"])){
        //  header("location:register.html");
        $have_skill = array();
        $dontHave_skill = array();
        //}
        $username = $_SESSION["username"];
        $var1 = $var2 = $var2 = $var3 = $var4 = $var5 = $var6 = $var7 = 0;



        $percentage = 0;
        //&& $_SERVER['PHP_SELF'] != "/cs161b/recruiterParser.php"
        if (isset($_FILES['file'])) {

            switch ($_FILES['file']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $_SESSION["set"] = true;
                    header("location:" . $_SERVER['HTTP_REFERER']);
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                default:
                    header("location:" . $_SERVER['HTTP_REFERER']);
            }
            $target_file = basename($_FILES["file"]["name"]);
            // SplFileObject::next(void);
            $extension = pathinfo($target_file, PATHINFO_EXTENSION);
            $length = strlen($extension);
            $conName = substr($target_file, 0, strlen($target_file) - ($length + 1));

            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {


                $myfile = fopen($target_file, "r");
                $file = new SplFileObject($target_file);

//                $have_skill = array();
//                $dontHave_skill = array();
                //if username field is empty...print error 'required'
                if (empty($_POST['check[]']) && empty($_POST['posTitle'])) {
                    $skillRequired = "Required*";

                    //if username field is not empty...get the submitted value
                }
                //if username field is empty...print error 'required'
                if (empty($_POST['company'])) {
                    $cmpRequired = "Required*";

                    //if username field is not empty...get the submitted value
                } else {
                    $company = mysql_fix_string($conn, $_POST['company']);
                }
                $rowcount = "";
                $posTitle = $_POST['posTitle'];

                function read_docx($filename) {

                    $striped_content = '';
                    $content = '';

                    if (!$filename || !file_exists($filename))
                        return false;

                    $zip = zip_open($filename);
                    if (!$zip || is_numeric($zip))
                        return false;

                    while ($zip_entry = zip_read($zip)) {

                        if (zip_entry_open($zip, $zip_entry) == FALSE)
                            continue;

                        if (zip_entry_name($zip_entry) != "word/document.xml")
                            continue;

                        $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

                        zip_entry_close($zip_entry);
                    }
                    zip_close($zip);
                    $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
                    $content = str_replace('</w:r></w:p>', "\r\n", $content);
                    $striped_content = strip_tags($content);

                    return $striped_content;
                }

                function match($content) {
                    global $target_file, $percentage, $have_skill, $extension, $dontHave_skill, $company, $conn, $rowcount, $username, $posTitle;
                    // if(isset($_POST['posTitle'])){
                    // $posTitle = $_POST['posTitle'];
                    //}
                    $rowRes = $conn->query("SELECT skills FROM skills WHERE company = '$company' AND posTitle = '$posTitle'");
                    //go through the result set and see if it matches the password for that username

                    if ($rowRes->num_rows > 0) {

                        while ($row = $rowRes->fetch_assoc()) {

                            $skill = $row["skills"];

                            if ($skill == "c++") {
                                $pattern = "/$skill\+\+/i";
                            } else {

                                $pattern = "/$skill/i";
                            }

                            if (preg_match($pattern, $content, $matches)) {

                                //if(in_array($skill, $matches)){
                                if (!in_array($skill, $have_skill)) {

                                    array_push($have_skill, $skill);
                                }
                                //}
                            } else {

                                //if (!in_array($skill, $matches)) {
                                if (!in_array($skill, $dontHave_skill) && !in_array($skill, $have_skill)) {
                                    array_push($dontHave_skill, $skill);
                                }
                                //}
                            }
                        }
                        $rowcount = mysqli_num_rows($rowRes);
                    } else {

                        // header("location:recruiter.php");
                    }


                    return false;
                }

                if ($extension == "docx") {
                    $content = read_docx($target_file);
                    $separator = "\r\n";
                    $line = strtok($content, $separator);

                    while ($line !== false) {

                        match($line);

                        $line = strtok($separator);
                    }
                    //$content = fgets($content);
                } else {
                    while (!$file->eof()) {
                        $content = fgets($myfile);

                        $content = trim($file->current());
                        match($content);

                        $file->next();
                    }
                }
                $percentage = ceil(sizeof($have_skill) * 100 / $rowcount);


                $stm1 = ("SELECT * FROM canresult WHERE company='$company' AND position = '$posTitle' AND name = '$conName'");
                $rowRes = $conn->query($stm1);
                if ($rowRes->num_rows > 0) {

                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("UPDATE canresult SET percentage='$percentage' WHERE company = '$company' AND position= '$posTitle' AND name = '$conName'");
                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "up";
                    }
                } else {

                    if (is_nan($percentage)) {
                        
                    } else
                        $stm = ("INSERT INTO canresult(position,company,name,percentage) VALUES('$posTitle','$company','$conName','$percentage')");

                    if ($conn->query($stm) === true) {
                        
                    } else {
                        echo mysqli_error($conn) . "pp";
                    }
                }


                $rowRes = $conn->query("SELECT * FROM canresult WHERE name= '$conName' AND company = '$company' order by percentage desc");


                if ($rowRes->num_rows > 0) {

                    $i = 1;

                    while ($row = $rowRes->fetch_assoc()) {
                        //${"var" . $i} = $row['percentage'];


                        ${"var" . $i} = $row["percentage"];
                        ${"name" . $i} = $row['name'];
                        ${"comp" . $i} = $row['company'];
                        $i++;
                    }
                }
            } else {


                $rowRes = $conn->query("SELECT * FROM canresult WHERE name = '$conName'");

                if ($rowRes->num_rows > 0) {
                    $i = 1;
                    while ($row = $rowRes->fetch_assoc()) {
                        ${"var" . $i} = $row['percentage'];
                        ${"name" . $i} = $row['name'];
                        ${"comp" . $i} = $row['company'];

                        $i++;
                    }
                }
            }
        }else{
            header("location:" . $_SERVER['HTTP_REFERER']);
        }

//sanitize user input
        function mysql_fix_string($conn, $string) {
            if (get_magic_quotes_gpc()) {
                $string = stripslashes($string);
                return $conn->real_escape_string($string);
            } else
                return $string;
        }
        ?>
        <p><?php 
           if($percentage>=85){echo "<p style='color:white;background-color: green;text-align:center'>$percentage% Match=>good fit!";}else
           if($percentage>=70){echo "=><p style='color:white;background-color: green;text-align:center'>$percentage% Match=><b>good condidate!</b>";}else
           if($percentage<70){echo "<p style='color:white;background-color: green;text-align:center'>$percentage% Match=> <b>No fit!</b></p>";} ?></p>
        <div class="header">            
            <a class="btn btn-primary" href="destroy_session.php">
                <button onclick="document.getElementById('login').style.display = 'block'" style="width:auto;color: red" class="loginbtn">Log Out</button></a>

        </div>
        <div name="dv" class="chartcontainer">
            <script type="text/javascript">

                window.onload = function () {

                        CanvasJS.addColorSet("greenShades",
                        [//colorSet Array

                            "#90EE90",
                            "green"
                           
                            
                            
                        ]);

                    var chart = new CanvasJS.Chart("chartContainer", {
                        
                       colorSet: "greenShades",
                        title: {
                            text: "Scan Result"
                        },
                        data: [
                            {
                                // Change type to "doughnut", "line", "splineArea", etc.
                                name: "dd",
                                type: "doughnut",
                                dataPoints: [

                                    {label: '<?php echo $name1; ?>', y: <?php echo $var1; ?>},
                                    {label: '<?php echo $company . "[" . $posTitle . "]"; ?>', y: <?php echo 100-$var1; ?>},
                                ]
                            }
                        ]
                    });
                    chart.render();

                };



            </script>

        </div>
        <div id="chartContainer" style="height: 400px; width: 100%; "></div>
        <div  style="height: 2px; width: 100%;background-color: darkslategrey"></div><br>

        <div style="height: auto; width: 100%;float:right;background-color: #CCCCCC; ">
            <div id="call" style=" margin: auto;
                 width: 30%;
                 border: 1px dotted green;
                 padding: 10px;text-align: center;float: left;">

                <?php
                $rowRes = $conn->query("SELECT * FROM user WHERE userName = (SELECT uname FROM skills WHERE company = '$company' AND posTitle = '$posTitle' LIMIT 1) AND title = 'recruiter' ");
                
                if ($rowRes->num_rows > 0) {
                    $i = 1;

                    while ($row = $rowRes->fetch_assoc()) {
                        $email = $row['email'];
                        $fname = strtoupper($row['fName']);
                        $lname = strtoupper($row['lName']);                        
                        echo <<<EOL
                        
    <b>Recruiter:</b> <a style='background-color: #EAFAF1;
     border:1px dotted green                   
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;' href="mailto:$email?body=''">$fname $lname | <u>Email</u> </a>
EOL;
                        echo '<br>';
                        //echo '<p>';
                        //echo "<a href='mailto:" .$email . "?body=" .  $email . "'>"; 
                        //echo "<a href='mailto:{$email}?body={$email}'>";
                        // echo '</p>';
                    }
                }
                ?>
            </div>
            <div style=" margin: auto;
                 width: 30%;
                 border: 1px dotted green;
                 padding: 10px;text-align: center;float: right;">

                <p style=" margin: auto; text-align: center;
                   width: 30%;
                   border: 1px dotted green ;
                   padding: 10px;"><b>Have Skills:</b></p>
<?php
foreach ($have_skill as $skill) {
   // if (in_array($skill, $dontHave_skill)) {
        
   // } else {
        echo '<p>';
        echo $skill;
        echo '</p>';
    }
//}
?>
            </div>

            <div style=" margin: auto;
                 width: 30%;
                 border: 1px dotted red;
                 padding: 10px;text-align: center;">
                <p style=" margin: auto; text-align: center;
                   width: 50%;
                   border: 1px dotted red ;
                   padding: 10px;"><b>Missing Skills:</b></p>
<?php
foreach ($dontHave_skill as $skill) {
    if (in_array($skill, $have_skill)) {
        
    } else {
        echo '<p>';
        echo $skill;
        echo '</p>';
    }
}
?>
            </div>
        </div>
    </body>
</html>
