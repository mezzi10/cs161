<?php

        //connect to database
        require_once'connect_database.php';


        $fName = $lName = $username = $password = $password2 = $email = $email2 = $title = "";


        $UnRequired = $PwRequired = $EmRequired = $FnRequired = $LnRequired = "";

//$conn = new mysqli("localhost", "messi55", "messi", "cs161");
        if ($conn->connect_error) {
            echo 'jjj';
        }
        //$query = "SELECT * FROM users";



        if ($_SERVER["REQUEST_METHOD"] == "POST") {
           
            if (empty($_POST['username']) || empty($_POST['password'])                                           
                                          || empty($_POST['email'])                                          
                                          || empty($_POST['title'])
                                          || empty($_POST['phone'])
                                          || empty($_POST['fname'])
                                          || empty($_POST['lname'])
                    ) {

                if (empty($_POST['username'])) {

                    $UnRequired = "Required*";
                } else {

                    $username = mysql_fix_string($conn, $username);
                }
                if (empty($password = $_POST['password'])) {

                    $PwRequired = "Required*";
                } else {
                    $password = mysql_fix_string($conn, $password);
                }
                
                if (empty($password = $_POST['email'])) {

                    $EmRequired = "Required*";
                } else {
                    $email = mysql_fix_string($conn, $email);
                }
                
                if (empty($title = $_POST['title'])) {

                    $titRequired = "Required*";
                } else {
                    $title = mysql_fix_string($conn, $title);
                }
                if (empty($phone = $_POST['phone'])) {

                    $phRequired = "Required*";
                }
                if (empty($fname = $_POST['fname'])) {

                    $fnRequired = "Required*";
                }
                if (empty($lname = $_POST['lname'])) {

                    $fnRequired = "Required*";
                }
                if (empty($lname = $_POST['phone'])) {

                    $fnRequired = "Required*";
                }
            } else {
                
                //get the value of username after sanitizing input and convert it to lower case
                $username = strtolower(mysql_fix_string($conn, $_POST['username']));
                //get the value of password, convert it to lower case and hash it
                $password = sha1(strtolower(mysql_fix_string($conn, $_POST['password'])));
                $email = strtolower(mysql_fix_string($conn, $_POST['email']));
                $title = strtolower(mysql_fix_string($conn, $_POST['title']));
                $phone = strtolower(mysql_fix_string($conn, $_POST['phone']));
                $fname = trim(strtolower(mysql_fix_string($conn, $_POST['fname'])));
                $lname = trim(strtolower(mysql_fix_string($conn, $_POST['lname'])));
                



                //check if username exists
                $recExists = "SELECT * FROM user WHERE userName='$username'";
                $result = mysqli_fetch_array($conn->query($recExists));
                
                //check if email exists
                $emExists = "SELECT * FROM user WHERE email='$email'";
                $result2 = mysqli_fetch_array($conn->query($emExists));

                //if username exists...print error
                if ($result != false && $result2 != false) {
                    $UnRequired = "userName exists*";

                    //otherwise...insert a new record with the new username and password   
                } else {
                    //create a directory for the new user
                    mkdir($username);
                    $stm = ("INSERT INTO user(title,userName,email,passWord,phone,fname,lname) "
                            . "VALUES('$title','$username','$email','$password','$phone','$fname','$lname')");
                    //if record was inserted successfully...forward user to log in page
                    if ($conn->query($stm) === true) {
                        if($title == "recruiter"){
                             $_SESSION["username"] = $username;
                           header("location:recruiter.php"); 
                        }else
                          $_SESSION["username"] = $username;
                           header("location:candidate.php");
                    } else {
                        echo mysqli_error($conn);
                    }
                }
            }
        }

//sanitize user input
        function mysql_fix_string($conn, $string) {
            if (get_magic_quotes_gpc()) {
                $string = stripslashes($string);
                return $conn->real_escape_string($string);
            }
            return $string;
        }
        ?>
