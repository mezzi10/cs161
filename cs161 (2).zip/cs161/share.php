<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include_once './connect_database.php';
       use PHPMailer\PHPMailer\PHPMailer;
      // use PHPMailer\PHPMailer\Exception;

require './PHPMailerr/src/Exception.php';
require './PHPMailerr/src/PHPMailer.php';
require './PHPMailerr/src/SMTP.php';
          $mail = new PHPMailer;

$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'root';          // SMTP username
$mail->Password = ''; // SMTP password
$mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                          // TCP port to connect to

$mail->setFrom('c.messi55.hotmailcom', 'CodexWorld');
$mail->addReplyTo('info@example.com', 'CodexWorld');
$address = "c.messi55.hotmail.com";
$mail->AddAddress($address, "John Doe");
//$mail->addAddress('c.messi55.hotmail.com');   // Add a recipient
$mail->addCC('c.messi55.hotmailcom');
$mail->addBCC('c.messi55.hotmailcom');

$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '<h1>How to Send Email using PHP in Localhost by CodexWorld</h1>';
$bodyContent .= '<p>This is the HTML email sent from localhost using PHP script by <b>CodexWorld</b></p>';

$mail->Subject = 'Email from Localhost by CodexWorld';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
            
        ?>
    </body>
</html>
